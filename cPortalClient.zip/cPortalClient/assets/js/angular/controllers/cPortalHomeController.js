angular.module("cPortal.controllers")
.controller("cPortalHomeController",function($scope,$rootScope,serviceApi,$location){
	
});