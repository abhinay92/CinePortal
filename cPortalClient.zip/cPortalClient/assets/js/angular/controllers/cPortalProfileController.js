angular.module("cPortal.controllers")
.controller("cPortalProfileController",function($scope,$rootScope,serviceApi,$location){
	
});