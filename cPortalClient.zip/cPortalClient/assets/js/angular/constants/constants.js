var constants = angular.module('cPortal.constants', [])
constants.constant('javaServiceContext', "");
constants.constant('nodeServiceContext', "");


